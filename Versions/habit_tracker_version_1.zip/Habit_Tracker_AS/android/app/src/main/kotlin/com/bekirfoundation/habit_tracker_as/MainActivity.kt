package com.bekirfoundation.habit_tracker_as

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
