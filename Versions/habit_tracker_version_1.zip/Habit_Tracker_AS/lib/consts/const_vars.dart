import 'package:flutter/material.dart';
import 'package:hexcolor/hexcolor.dart';

final Color backgroundC = HexColor('#363537');
final Color mainC = HexColor('#ED7D3A');
const Color textC = Color(0xFFFFFFFF);