import 'package:flutter/material.dart';
import 'consts/const_vars.dart';
import 'package:material_color_generator/material_color_generator.dart';
import 'package:google_fonts/google_fonts.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Habit Tracker',
      theme: ThemeData(
        primarySwatch: generateMaterialColor(color: mainC),
        primaryColor: mainC,
        textTheme: GoogleFonts.interTextTheme(),
        dividerColor: mainC,
      ),
      home: const MyHomePage(title: 'HABIT TRACKER'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  State<MyHomePage> createState() => HomePage();
}

class HomePage extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        titleTextStyle: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.bold,
          letterSpacing: 1.5,
        ),
        centerTitle: true,
        toolbarHeight: 80,
      ),
      backgroundColor: backgroundC,
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Column(
            children: const [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 105, 0, 50),
                child: Text(
                  '29.09.2022 - 04.09.2022',
                  style: TextStyle(
                    fontSize: 24,
                    color: Color(0xFFFFFFFF),
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              HabitTable(),
            ],
          ),
        ),
      ),
    );
  }
}


class HabitTable extends StatefulWidget {
  const HabitTable({Key? key}) : super(key: key);

  @override
  State<HabitTable> createState() => _HabitTableState();
}

class _HabitTableState extends State<HabitTable> {
  final double _tableLineThickness = 1.0;

  @override
  Widget build(BuildContext context) {
    return DataTable(
      border: TableBorder.all(
        width: _tableLineThickness,
        color: mainC,
      ),
      dividerThickness: _tableLineThickness,
      columns: const [
        DataColumn(label: DayContainer(title: '')),
        DataColumn(label: DayContainer(title: 'Mon.')),
        DataColumn(label: DayContainer(title: 'Tue.')),
        DataColumn(label: DayContainer(title: 'Wed.')),
        DataColumn(label: DayContainer(title: 'Th.')),
        DataColumn(label: DayContainer(title: 'Fri.')),
        DataColumn(label: DayContainer(title: 'Sun.')),
        DataColumn(label: DayContainer(title: 'Sat.')),
      ],
      columnSpacing: 0,
      rows: const [
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Reading')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Fitness')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Coding')),
            DataCell(Text(''), placeholder: true),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Gratitude-Journaling')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Day-Journaling')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Stretch')),
            DataCell(HabitNameContainer(title: 'Stretch')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Meditate')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        ),
        DataRow(
          cells: [
            DataCell(HabitNameContainer(title: 'Meditate')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
            DataCell(Text('')),
          ],
        )
      ],
    );
  }
}


class HabitNameContainer extends StatelessWidget {
  const HabitNameContainer({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 13,
        letterSpacing: 0.5,
        color: Colors.white,
      ),
      textAlign: TextAlign.start,
    );
  }
}

class DayContainer extends StatelessWidget {
  const DayContainer({Key? key, required this.title}) : super(key: key);

  final String title;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 40,
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 12,
          letterSpacing: 0.5,
          color: Colors.white,
        ),
        textAlign: TextAlign.center,
      ),
    );
  }
}
